<?php

namespace App\Console\Commands;
use DB;
use Faker\Factory as Faker;
use Illuminate\Console\Command;

class customCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'customCommand:generate {count} {--queue}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Generate Fake users ';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {     $count = $this->argument('count');
        $faker = Faker::create('App\User');
        for ($i=0; $i<=$count;$i++) {
            DB::table('users')->insert([
                'name' => $faker->name(),
                'email' => $faker->email(),
                'password' => $faker->password(),
                'created_at' => \Carbon\Carbon::now(),
                'Updated_at' => \Carbon\Carbon::now(),
            ]);


        }
        $this->info('Data is generated successfully');
    }
}
