-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 22, 2019 at 02:55 PM
-- Server version: 8.0.12
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_06_19_112029_create_admins_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isAdmin` tinyint(1) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `isAdmin`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Jaquan Monahan', 'keara.feil@yahoo.com', NULL, NULL, 'c=RUQ6tF|;l>1ee]ET];', NULL, '2019-06-18 16:26:37', '2019-06-18 16:26:37'),
(2, 'Ms. Rosalee Daugherty Sr.', 'ogislason@kris.com', NULL, NULL, 'a!\\3{q\\Tt?p`?2XuY&', NULL, '2019-06-18 16:26:37', '2019-06-18 16:26:37'),
(3, 'Dr. Mittie Connelly IV', 'sgorczany@bartell.com', NULL, NULL, 'ih4{wQq]', NULL, '2019-06-18 16:26:37', '2019-06-18 16:26:37'),
(14, 'Lusine', 'hjk@ro.ru', 1, NULL, '$2y$10$C7.5sOUXtx9sI/pvbb/EruD2fLmMkYx9mh8U5LVG2xfoJVv4BV4Vm', NULL, '2019-06-19 18:02:40', '2019-06-19 18:02:40'),
(15, 'Lusine', 'syuzi@mail.ru', 0, NULL, '$2y$10$C5yNejl9cWVVN2TrRU5DpOROq8ZeEyx/VisLSSrUSGvF2SL6r9lu6', NULL, '2019-06-19 18:03:17', '2019-06-19 18:03:17'),
(16, 'Syuzi', 'lus@ro.ru', 0, NULL, '$2y$10$.dg1NLDMM5gyhqgCqDp2Wu/LW1xYi7EhtoR7mWBvw/mBZDB8QUN/O', 'fuOxRnHcPhjAevpy0FdNpHMZcdsSjxoOAsNztpYa1jRmcD3i6Ac4hywmohSX', '2019-06-19 18:53:30', '2019-06-19 18:53:30'),
(17, 'Kattie Harber', 'tankunding@hotmail.com', NULL, NULL, '{jj[O/C\"v{~TgtVh', NULL, '2019-06-19 19:24:42', '2019-06-19 19:24:42'),
(18, 'Keagan Schaden DDS', 'glover.rahul@gmail.com', NULL, NULL, 'UoHfgW7S', NULL, '2019-06-19 19:24:42', '2019-06-19 19:24:42'),
(19, 'Demetris Klocko', 'kessler.burnice@gmail.com', NULL, NULL, 'tf`ab?euFmDM', NULL, '2019-06-19 19:24:42', '2019-06-19 19:24:42'),
(20, 'D\'angelo Wolf', 'qtremblay@hotmail.com', NULL, NULL, '^1^9]:', NULL, '2019-06-19 19:24:42', '2019-06-19 19:24:42'),
(21, 'Saige Blick', 'kohler.talon@stehr.com', NULL, NULL, '_;|@*[Q6T6U', NULL, '2019-06-19 19:24:42', '2019-06-19 19:24:42'),
(22, 'Mr. Doyle Prosacco', 'iliana40@runolfsson.com', NULL, NULL, 'D\"#ykEqlu]i}-', NULL, '2019-06-19 19:24:42', '2019-06-19 19:24:42'),
(23, 'Mr. Freddy Jast DDS', 'joannie00@okuneva.com', NULL, NULL, '6%Lw2YlL#GWhy~_|Bj', NULL, '2019-06-19 19:24:42', '2019-06-19 19:24:42'),
(24, 'Derick Klein', 'bosco.isaac@hotmail.com', NULL, NULL, '9#[k=;@cD&5|', NULL, '2019-06-19 19:24:42', '2019-06-19 19:24:42'),
(25, 'Prof. Ida Larkin Sr.', 'logan84@okuneva.org', NULL, NULL, '|8yp3^+#%OV[E=N', NULL, '2019-06-19 19:24:42', '2019-06-19 19:24:42'),
(26, 'Christiana Haley', 'lubowitz.bruce@durgan.org', NULL, NULL, 'e*3\"U;4Fe+}.]iJ<0', NULL, '2019-06-19 19:24:42', '2019-06-19 19:24:42'),
(27, 'Danielle Schulist', 'ellen.trantow@rosenbaum.com', NULL, NULL, 'd3A~v.v{t<:@,$vSx83', NULL, '2019-06-19 19:24:42', '2019-06-19 19:24:42'),
(28, 'Orlando Walker', 'fhirthe@yahoo.com', NULL, NULL, '^x.s9sGlQB=oJZ;', NULL, '2019-06-21 16:32:58', '2019-06-21 16:32:58'),
(29, 'Cathryn Zboncak', 'dewayne.roberts@herzog.org', NULL, NULL, 'x;>OJNF', NULL, '2019-06-21 16:33:03', '2019-06-21 16:33:03'),
(30, 'Erik Zulauf', 'feeney.maude@kulas.com', NULL, NULL, 'm$XA1gPAewvVEu{e', NULL, '2019-06-21 16:33:03', '2019-06-21 16:33:03'),
(31, 'Miss Joanny Feeney', 'mtreutel@yahoo.com', NULL, NULL, 'c+66Mx_ob', NULL, '2019-06-21 16:33:03', '2019-06-21 16:33:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
