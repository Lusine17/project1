<?php
return ['admin_emails' => explode(', ',  env('lusine.harutyunyan@ro.ru'))];